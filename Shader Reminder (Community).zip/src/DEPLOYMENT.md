# Deployment Guide - Reminder App

## Quick Deploy to Vercel (5 minutes) 🚀

### Step 1: Get the Code to GitHub

Since you're using Figma Make, here's how to get the code:

**Option A: Download from Figma Make**
1. Look for a "Download", "Export", or "Share" button in Figma Make
2. Download the project as a ZIP file
3. Extract the ZIP on your computer

**Option B: Copy Files Manually**
1. Open your browser's Developer Tools (F12)
2. Go to the "Sources" or "Network" tab
3. Find and save each file manually

**Option C: Use Figma Make's Deploy Feature**
1. Look for a "Deploy" or "Publish" button
2. Connect directly to Vercel through Figma Make

### Step 2: Upload to GitHub

1. Go to [github.com/new](https://github.com/new)
2. Create a new repository:
   - Name: `reminder-app`
   - Visibility: Public
   - ✅ Add README file
3. Click "Create repository"
4. Click "Add file" → "Upload files"
5. Drag ALL project files into the browser
6. Click "Commit changes"

### Step 3: Deploy to Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Click "Import Git Repository"
3. Select your `reminder-app` repository
4. Click "Import"
5. Vercel will auto-detect settings:
   - Framework: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`
6. Click "Deploy"
7. Wait 2-3 minutes ☕
8. **DONE!** Your app is live! 🎉

You'll get a URL like: `https://reminder-app-xxxxx.vercel.app`

---

## Alternative: Deploy to Netlify

### Via Drag & Drop (Easiest)

1. Build locally first:
   ```bash
   npm install
   npm run build
   ```
2. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
3. Drag the `dist` folder into the browser
4. **DONE!** Get URL: `https://xxxxx.netlify.app`

### Via GitHub

1. Upload code to GitHub (same as Step 2 above)
2. Go to [app.netlify.com](https://app.netlify.com)
3. Click "Add new site" → "Import from Git"
4. Select your repository
5. Settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Click "Deploy"

---

## Add Custom Domain (Optional)

### After deploying to Vercel:

1. Buy a domain from:
   - [Namecheap.com](https://namecheap.com) (~$12/year)
   - [Louhi.fi](https://louhi.fi) (~15€/year for .fi domains)

2. In Vercel:
   - Go to your project → Settings → Domains
   - Add your domain (e.g., `myapp.com`)
   - Copy the nameserver addresses Vercel gives you

3. At your domain registrar:
   - Find DNS/Nameserver settings
   - Update nameservers to Vercel's
   - Wait 1-24 hours for DNS propagation

4. **DONE!** Your app is at `https://myapp.com`

---

## Troubleshooting

### "Build failed" on Vercel
- Make sure `package.json` exists
- Check that all files uploaded correctly
- Look at the error log and search for the specific error

### "Cannot find module" errors
- Ensure all component imports use correct paths
- Check that all files are in the right folders

### "White screen" after deployment
- Check browser console for errors (F12)
- Verify all asset paths are correct
- Make sure `index.html` has the script tag

### Need help?
- Check Vercel docs: [vercel.com/docs](https://vercel.com/docs)
- Netlify docs: [docs.netlify.com](https://docs.netlify.com)

---

## Environment Variables (if needed later)

If you add API keys or secrets:

1. In Vercel: Settings → Environment Variables
2. Add variables like:
   - `VITE_API_KEY=your_key_here`
3. Redeploy the app

---

## Updating Your Deployed App

1. Make changes in Figma Make
2. Download updated files
3. Commit to GitHub:
   ```bash
   git add .
   git commit -m "Update app"
   git push
   ```
4. Vercel auto-deploys! (30 seconds later it's live)

---

**Questions? Check README.md or create an issue on GitHub!**
