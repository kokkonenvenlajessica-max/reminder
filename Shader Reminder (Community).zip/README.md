
  # Shader Reminder (Community)

  This is a code bundle for Shader Reminder (Community). The original project is available at https://www.figma.com/design/s7TnfkjEW2JMQRYf3rV25N/Shader-Reminder--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  